//
//  MyZelleProxy.h
//  MyZelleProxy
//
//  Created by Rac on 23/06/22.
//

#import <Foundation/Foundation.h>

//! Project version number for MyZelleProxy.
FOUNDATION_EXPORT double MyZelleProxyVersionNumber;

//! Project version string for MyZelleProxy.
FOUNDATION_EXPORT const unsigned char MyZelleProxyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyZelleProxy/PublicHeader.h>


